/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package servis;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Evento;

/**
 *
 * @author ivan_
 */
public interface Inventariable<T extends Evento> {
        
    void agregar(T item);
    
    T obtener(int indice);
    
    void eliminar(int indice);
    
    List<T> filtrar(Predicate<T> predicate);
    
    List<T> buscarPorRango(LocalDate primerFecha, LocalDate segundaFecha);
    
    void ordenarNatural();
    
    void ordenar(Comparator<T> comparador);
    
    void guardarEnBinario(String path);
    
    void cargarDesdeBinario(String path);
    
    void guardarEnCSV(String path);
    
    void cargarDesdeCSV(String path);
    
}
