/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servis;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import model.Evento;
import model.EventoMusical;

/**
 *
 * @author ivan_
 */
public class GestorEventos<T extends Evento> implements Inventariable<T>{
    
    List<T> lista = new ArrayList<T>();
    
    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new NullPointerException();
        }
        //depues de que verifica que no sea null agreaga el elemento a la lista
        lista.add(item);
    }
    
     private void validarIndice(int indice){
         //verifica que el indice no sea negativo y este dentro del rango
        if (indice < 0 || indice >= lista.size()) {
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }
    
    @Override
    public T obtener(int indice) {
        //obtiene el elemento segun el indice
         validarIndice(indice);
        return lista.get(indice);
    }

    @Override
    public void eliminar(int indice) {
        //elimina el elemento segun el indice
        validarIndice(indice);
        lista.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicate) {
        
        List<T> toReturn = new ArrayList<>();
        
        for (T t : lista) {
            //segun el criterio dado pasa el test y se agrega
            if (predicate.test(t)) {
                toReturn.add(t);
            }
        }
        
        return toReturn;
    }

    @Override
    public List<T> buscarPorRango(LocalDate primerFecha, LocalDate segundaFecha) {
        List<T> toReturn = new ArrayList<>();
        
        for (T t : lista) {
            //verifica que la fecha este dentro del rango que se recibe por paramentro, segun 
            if (t.getFecha().compareTo(primerFecha) >= 0 && t.getFecha().compareTo(segundaFecha) <= 0) {
                //si pasa el criterio se agrega a toReturn
                toReturn.add(t);
            }
        }
        
        return toReturn;
        
    }

    @Override
    public void ordenarNatural() {
        //ordenamiento natual utilizado la sobre escritura con comparator
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }
    
    @Override
    public void ordenar(Comparator<T> comparador) {
        //segun el criterio ordena la lista
        lista.sort(comparador);
    }

    @Override
    public void guardarEnBinario(String path) {
        //gardado en binario
        try(FileOutputStream archivo = new FileOutputStream(path);
          ObjectOutputStream salida = new ObjectOutputStream(archivo)){
            //tranformo el objeto
            salida.writeObject(lista);
            
        }catch(IOException ex){
            //imprime la pila de llamadas 
            ex.printStackTrace();
        }
    }

    @Override
    public void cargarDesdeBinario(String path) {
        //carga desde binario
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
           //pisa la lista que ya tengo
           lista = (List<T>) input.readObject();
            
        } catch (IOException | ClassNotFoundException ex) {
            //si en el catch hago lo mismo puedo juntarlas, multicatch
            ex.printStackTrace();
        }
        
    }

    @Override
    public void guardarEnCSV(String path) {
        File archivo = new File(path);
        //verifica que el archivo no este creado
        try {
            if (archivo.exists()) {
                System.out.println("El archivo ya existe");        
            }
            else{
                archivo.createNewFile();
            }

        } catch (IOException ex) {
            
            System.out.println("Ocurrio un error al crear el archivo");
            
        }
        
        //guardado a csv
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            
            bw.write("id,nombre,fecha,artista,genero\n");//encabezado
            for (T item : lista){
                //escribo en el csv
                bw.write(item.toCSV() + "\n");
            }
            
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void limpiar(){
        //limpio la lista para reutilizar
        lista.clear();
    }
    
    @Override
    public void cargarDesdeCSV(String path) {
        
        //carga el csv en la lista previamente limpiada
        try ( BufferedReader bf = new BufferedReader(new FileReader(path))){
            
            String linea;
            //la primer linea es la del encabezado, salteo lectura fantasma
            bf.readLine();
            
            while((linea = bf.readLine()) != null){
                
                lista.add((T) EventoMusical.fromCSV(linea));
                
            }
            
           
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } 
       
    }
    
    public void mostrarTodos(){
        for (T t : lista) {
            System.out.println(t);
        }
        
    }
    
    
}
