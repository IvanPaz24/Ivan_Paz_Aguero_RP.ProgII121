/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author ivan_
 */
public class AppConstans {
    //guardo los path que necesite y con Path los adapta segun windows o linux
    public static final Path  PATH_ARCHIVOS = Paths.get("src/data/");
    public static final  Path SERIAL = PATH_ARCHIVOS.resolve("eventos.bin");
    public static final Path CSV = PATH_ARCHIVOS.resolve("eventos.csv");
    
}
