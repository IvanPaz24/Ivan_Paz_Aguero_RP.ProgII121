/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author ivan_
 */
public class EventoMusical extends Evento implements Comparable<EventoMusical>, Serializable{
    
    private String artista;
    private GeneroMusical genero;
    
    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    public String getArtista() {
        return artista;
    }

    @Override
    public String toString() {
        return super.toString()  + " ,artista=" + artista + ", genero=" + genero + '}';
    }
    
    
    @Override
    public int compareTo(EventoMusical o) {
        //compara segun la fecha
        return getFecha().compareTo(o.getFecha());
    }
    
    public String toCSV(){
        //devuelvo los datos en String para cargar en csv
        return super.toCSV() + "," + 
                artista + "," + genero.toString();
    }
    
    public static EventoMusical fromCSV(String eventoCSV){
        //verifico los saltos de lineas
        if (eventoCSV.endsWith("\n")) {
            eventoCSV = eventoCSV.substring(0 , eventoCSV.length() - 1 );
        }
        //los separo segun la coma
        String[] valores = eventoCSV.split(",");
        
        if (valores.length == 5) {
            //los transformo segun lo que requiera el objeto
            return new EventoMusical(Integer.parseInt(valores[0]), 
            valores[1],
            LocalDate.parse(valores[2]),
            valores[3],
            GeneroMusical.valueOf(valores[4]));
            
        }
        
        return null;
        
    }
    
}
